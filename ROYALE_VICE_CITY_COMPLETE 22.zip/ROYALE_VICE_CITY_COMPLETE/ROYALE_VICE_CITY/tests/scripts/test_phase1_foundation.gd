extends SceneTree
## Headless Phase 1 verification test runner.
## Run via: godot --headless --path . --script res://tests/scripts/test_phase1_foundation.gd

var _failures: Array[String] = []

func _init() -> void:
	call_deferred("_run_all_tests")

func _run_all_tests() -> void:
	print("=== ROYALE VICE CITY: Phase 1 Foundation Tests ===")
	_check_scene_exists("res://scenes/boot/BootScene.tscn")
	_check_scene_exists("res://scenes/boot/LoadingOverlay.tscn")
	_check_scene_exists("res://scenes/menus/MainMenu.tscn")
	_check_scene_exists("res://scenes/menus/SettingsMenu.tscn")
	_check_scene_exists("res://scenes/world/Phase1SandboxHub.tscn")

	_check_json_valid("res://data/localization/translations.json")
	_check_json_valid("res://data/config/graphics_presets.json")

	_test_autoloads()
	_test_save_roundtrip()

	if _failures.is_empty():
		print("RESULT: ALL PHASE 1 FOUNDATION CHECKS PASSED.")
		quit(0)
	else:
		for f in _failures:
			push_error("TEST FAILURE: %s" % f)
		print("RESULT: %d FAILURE(S)." % _failures.size())
		quit(1)

func _check_scene_exists(path: String) -> void:
	if not ResourceLoader.exists(path):
		_failures.append("Missing scene resource: %s" % path)
		return
	var packed := load(path) as PackedScene
	if packed == null:
		_failures.append("Failed to load PackedScene: %s" % path)

func _check_json_valid(path: String) -> void:
	if not FileAccess.file_exists(path):
		_failures.append("Missing JSON file: %s" % path)
		return
	var f := FileAccess.open(path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		_failures.append("Invalid JSON dictionary: %s" % path)

func _test_autoloads() -> void:
	var required := [
		"ErrorHandler",
		"EventBus",
		"LocalizationManager",
		"SaveManager",
		"AudioManager",
		"InputManager",
		"ContentPackManager",
		"SceneManager",
		"GameManager"
	]
	for name_key in required:
		if not root.has_node(name_key):
			_failures.append("Missing autoload node: %s" % name_key)

func _test_save_roundtrip() -> void:
	var save_mgr := root.get_node_or_null("SaveManager")
	if save_mgr == null:
		_failures.append("Cannot run SaveManager round-trip; autoload missing.")
		return
	var payload: Dictionary = save_mgr.call("create_new_save_data", 99)
	var saved_ok: bool = save_mgr.call("save_game", 99, payload)
	if not saved_ok:
		_failures.append("SaveManager.save_game(99) returned false.")
		return
	var loaded: Dictionary = save_mgr.call("load_game", 99)
	if loaded.is_empty() or int(loaded.get("slot", 0)) != 99:
		_failures.append("SaveManager.load_game(99) failed round-trip integrity check.")
