extends Node
## Threaded scene switcher with LoadingOverlay UI and path validation.

const LOADING_OVERLAY_SCENE := "res://scenes/boot/LoadingOverlay.tscn"

var _overlay_instance: CanvasLayer = null
var _is_transitioning: bool = false
var _loading_target: String = ""
var _progress_array: Array = []

func _ready() -> void:
	set_process(false)
	_instantiate_overlay()

func _instantiate_overlay() -> void:
	if not ResourceLoader.exists(LOADING_OVERLAY_SCENE):
		ErrorHandler.report_warning("SceneManager", "LoadingOverlay scene not found at %s" % LOADING_OVERLAY_SCENE)
		return
	var packed := load(LOADING_OVERLAY_SCENE) as PackedScene
	if packed != null:
		_overlay_instance = packed.instantiate() as CanvasLayer
		if _overlay_instance != null:
			_overlay_instance.visible = false
			add_child(_overlay_instance)

func change_scene(target_path: String) -> void:
	if _is_transitioning:
		return
	if not ResourceLoader.exists(target_path):
		ErrorHandler.report_error("SceneManager", "Target scene does not exist: %s" % target_path)
		return

	_is_transitioning = true
	_loading_target = target_path
	_progress_array.clear()
	EventBus.scene_transition_started.emit(target_path)

	if _overlay_instance != null and _overlay_instance.has_method("show_loading"):
		_overlay_instance.call("show_loading", 0.05)

	var err := ResourceLoader.load_threaded_request(target_path)
	if err != OK:
		ErrorHandler.report_warning("SceneManager", "Threaded load failed, falling back to synchronous load.")
		var packed := load(target_path) as PackedScene
		_finish_transition(packed)
		return

	set_process(true)

func _process(_delta: float) -> void:
	if _loading_target.is_empty():
		set_process(false)
		return

	var status := ResourceLoader.load_threaded_get_status(_loading_target, _progress_array)
	match status:
		ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			var pct := float(_progress_array[0]) if _progress_array.size() > 0 else 0.25
			if _overlay_instance != null and _overlay_instance.has_method("update_progress"):
				_overlay_instance.call("update_progress", pct)
		ResourceLoader.THREAD_LOAD_LOADED:
			set_process(false)
			var packed := ResourceLoader.load_threaded_get(_loading_target) as PackedScene
			_finish_transition(packed)
		ResourceLoader.THREAD_LOAD_FAILED, ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			set_process(false)
			ErrorHandler.report_error("SceneManager", "Failed loading scene: %s" % _loading_target)
			_reset_overlay()

func _finish_transition(packed: PackedScene) -> void:
	if _overlay_instance != null and _overlay_instance.has_method("update_progress"):
		_overlay_instance.call("update_progress", 1.0)

	if packed == null:
		ErrorHandler.report_error("SceneManager", "Loaded resource is not a PackedScene: %s" % _loading_target)
		_reset_overlay()
		return

	var err := get_tree().change_scene_to_packed(packed)
	if err != OK:
		ErrorHandler.report_error("SceneManager", "Tree scene switch failed: %s" % error_string(err))
		_reset_overlay()
		return

	var finished_path := _loading_target
	_reset_overlay()
	EventBus.scene_transition_finished.emit(finished_path)

func _reset_overlay() -> void:
	_is_transitioning = false
	_loading_target = ""
	if _overlay_instance != null and _overlay_instance.has_method("hide_loading"):
		_overlay_instance.call("hide_loading")
