extends Node
## Offline JSON-backed localization manager supporting instant runtime language switching.

const TRANSLATIONS_PATH := "res://data/localization/translations.json"
const DEFAULT_LOCALE := "en"

var _languages: Array[Dictionary] = []
var _strings: Dictionary = {}
var _current_locale: String = DEFAULT_LOCALE

func _ready() -> void:
	load_translations()

func load_translations() -> bool:
	if not FileAccess.file_exists(TRANSLATIONS_PATH):
		ErrorHandler.report_error("LocalizationManager", "Missing translations file: %s" % TRANSLATIONS_PATH)
		return false

	var file := FileAccess.open(TRANSLATIONS_PATH, FileAccess.READ)
	if file == null:
		ErrorHandler.report_error("LocalizationManager", "Failed to open translations file.")
		return false

	var raw := file.get_as_text()
	file.close()

	var parsed: Variant = JSON.parse_string(raw)
	if typeof(parsed) != TYPE_DICTIONARY:
		ErrorHandler.report_error("LocalizationManager", "Invalid JSON format in translations.json.")
		return false

	_languages.clear()
	var langs_raw: Array = parsed.get("languages", [])
	for item in langs_raw:
		if typeof(item) == TYPE_DICTIONARY:
			_languages.append(item)

	_strings = parsed.get("strings", {})
	ErrorHandler.log_info("LocalizationManager", "Loaded %d languages." % _languages.size())
	return true

func get_supported_languages() -> Array[Dictionary]:
	return _languages.duplicate()

func get_current_locale() -> String:
	return _current_locale

func set_locale(locale_code: String) -> void:
	if not _strings.has(locale_code):
		ErrorHandler.report_warning("LocalizationManager", "Unsupported locale '%s', falling back to '%s'." % [locale_code, DEFAULT_LOCALE])
		locale_code = DEFAULT_LOCALE
	_current_locale = locale_code
	TranslationServer.set_locale(locale_code)
	EventBus.language_changed.emit(locale_code)

func translate_key(key: String, replacements: Dictionary = {}) -> String:
	var table: Dictionary = _strings.get(_current_locale, {})
	var text: String = str(table.get(key, ""))
	if text.is_empty():
		var fallback: Dictionary = _strings.get(DEFAULT_LOCALE, {})
		text = str(fallback.get(key, key))
	for token in replacements.keys():
		text = text.replace("{%s}" % str(token), str(replacements[token]))
	return text
