extends Node
## Master coordinator for game state, settings application, campaign start/continue, and graphics presets.

const GRAPHICS_PRESETS_PATH := "res://data/config/graphics_presets.json"
const SCENE_MAIN_MENU := "res://scenes/menus/MainMenu.tscn"
const SCENE_SETTINGS := "res://scenes/menus/SettingsMenu.tscn"
const SCENE_PHASE1_HUB := "res://scenes/world/Phase1SandboxHub.tscn"

var active_save_data: Dictionary = {}
var graphics_presets: Dictionary = {}
var is_initialized: bool = false

func _ready() -> void:
	_load_graphics_presets()
	ErrorHandler.log_info("GameManager", "GameManager registered.")

func initialize_subsystems() -> void:
	var settings := SaveManager.load_settings()
	apply_all_settings(settings, false)
	ContentPackManager.scan_local_packs()
	is_initialized = true
	ErrorHandler.log_info("GameManager", "All Phase 1 subsystems initialized.")

func _load_graphics_presets() -> void:
	if not FileAccess.file_exists(GRAPHICS_PRESETS_PATH):
		return
	var f := FileAccess.open(GRAPHICS_PRESETS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY:
		graphics_presets = parsed.get("presets", {})

func apply_all_settings(settings: Dictionary, persist: bool = true) -> void:
	if persist:
		SaveManager.save_settings(settings)

	var audio: Dictionary = settings.get("audio", {})
	AudioManager.apply_volumes(
		float(audio.get("master_volume", 0.85)),
		float(audio.get("music_volume", 0.70)),
		float(audio.get("sfx_volume", 0.90))
	)

	var controls: Dictionary = settings.get("controls", {})
	InputManager.apply_control_settings(
		float(controls.get("camera_sensitivity", 1.0)),
		bool(controls.get("invert_y", false)),
		bool(controls.get("touch_haptics", true))
	)

	var lang: Dictionary = settings.get("language", {})
	LocalizationManager.set_locale(str(lang.get("locale", "en")))

	var graphics: Dictionary = settings.get("graphics", {})
	_apply_graphics_settings(
		str(graphics.get("quality", "high")),
		int(graphics.get("max_fps", 60))
	)

	EventBus.settings_applied.emit(settings)

func _apply_graphics_settings(quality_key: String, max_fps: int) -> void:
	var preset: Dictionary = graphics_presets.get(quality_key, {})
	var viewport := get_viewport()
	if viewport != null:
		var scale := float(preset.get("render_scale", 1.0))
		viewport.scaling_3d_scale = clampf(scale, 0.5, 1.0)
		var msaa := int(preset.get("msaa_3d", 0))
		viewport.msaa_3d = clampi(msaa, 0, 3) as Viewport.MSAA

	Engine.max_fps = clampi(max_fps, 30, 120)

func start_new_game() -> void:
	var new_save := SaveManager.create_new_save_data(SaveManager.PRIMARY_SLOT)
	if SaveManager.save_game(SaveManager.PRIMARY_SLOT, new_save):
		active_save_data = new_save
		var target := str(new_save.get("scene_path", SCENE_PHASE1_HUB))
		SceneManager.change_scene(target)

func continue_game() -> void:
	var loaded := SaveManager.load_game(SaveManager.PRIMARY_SLOT)
	if loaded.is_empty():
		ErrorHandler.report_warning("GameManager", "No valid save found to continue.", true)
		return
	active_save_data = loaded
	var target := str(loaded.get("scene_path", SCENE_PHASE1_HUB))
	SceneManager.change_scene(target)

func save_current_progress() -> bool:
	if active_save_data.is_empty():
		active_save_data = SaveManager.create_new_save_data(SaveManager.PRIMARY_SLOT)
	return SaveManager.save_game(SaveManager.PRIMARY_SLOT, active_save_data)

func open_main_menu() -> void:
	SceneManager.change_scene(SCENE_MAIN_MENU)

func open_settings() -> void:
	SceneManager.change_scene(SCENE_SETTINGS)
