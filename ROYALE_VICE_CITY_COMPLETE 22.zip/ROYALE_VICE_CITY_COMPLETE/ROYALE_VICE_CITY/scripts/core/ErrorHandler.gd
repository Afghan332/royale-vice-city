extends Node
## Centralized offline error logging and non-blocking user notice handler.

signal error_reported(severity: String, source: String, message: String)

const LOG_DIR := "user://logs"
const LOG_PATH := "user://logs/runtime.log"
const MAX_BUFFER_ENTRIES := 200

var _recent_errors: Array[Dictionary] = []

func _ready() -> void:
	_ensure_log_directory()
	log_info("ErrorHandler", "Offline error subsystem initialized.")

func _ensure_log_directory() -> void:
	var dir := DirAccess.open("user://")
	if dir != null and not dir.dir_exists("logs"):
		var err := dir.make_dir_recursive("logs")
		if err != OK:
			push_warning("[ErrorHandler] Could not create user://logs directory: %s" % error_string(err))

func log_info(source: String, message: String) -> void:
	_record("INFO", source, message, false)

func report_warning(source: String, message: String, notify_user: bool = false) -> void:
	push_warning("[%s] %s" % [source, message])
	_record("WARN", source, message, notify_user)

func report_error(source: String, message: String, notify_user: bool = true) -> void:
	push_error("[%s] %s" % [source, message])
	_record("ERROR", source, message, notify_user)

func _record(severity: String, source: String, message: String, notify_user: bool) -> void:
	var timestamp := Time.get_datetime_string_from_system(true, true)
	var entry := {
		"timestamp": timestamp,
		"severity": severity,
		"source": source,
		"message": message
	}
	_recent_errors.append(entry)
	if _recent_errors.size() > MAX_BUFFER_ENTRIES:
		_recent_errors.pop_front()
	_append_to_log_file(entry)
	if notify_user:
		error_reported.emit(severity, source, message)

func _append_to_log_file(entry: Dictionary) -> void:
	var file: FileAccess
	if FileAccess.file_exists(LOG_PATH):
		file = FileAccess.open(LOG_PATH, FileAccess.READ_WRITE)
		if file != null:
			file.seek_end()
	else:
		file = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	if file != null:
		file.store_line("[%s] [%s] [%s] %s" % [
			entry["timestamp"],
			entry["severity"],
			entry["source"],
			entry["message"]
		])
		file.close()

func get_recent_entries() -> Array[Dictionary]:
	return _recent_errors.duplicate()
