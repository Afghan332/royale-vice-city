extends Node
## Global decoupled signal bus for Phase 1+ subsystems.

signal language_changed(locale_code: String)
signal settings_applied(settings: Dictionary)
signal save_completed(slot_index: int, success: bool)
signal save_loaded(slot_index: int, data: Dictionary)
signal scene_transition_started(target_path: String)
signal scene_transition_finished(scene_path: String)
signal content_packs_scanned(pack_count: int)
