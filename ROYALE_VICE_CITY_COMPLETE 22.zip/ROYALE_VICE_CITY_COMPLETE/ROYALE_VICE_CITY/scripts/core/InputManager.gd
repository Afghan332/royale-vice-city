extends Node
## Manages touch sensitivity, Y-axis inversion, mobile haptics, and input action queries.

var camera_sensitivity: float = 1.0
var invert_camera_y: bool = false
var touch_haptics_enabled: bool = true

var virtual_move_vector: Vector2 = Vector2.ZERO
var virtual_look_delta: Vector2 = Vector2.ZERO

func _ready() -> void:
	ErrorHandler.log_info("InputManager", "Input subsystem ready.")

func apply_control_settings(sensitivity: float, invert_y: bool, haptics: bool) -> void:
	camera_sensitivity = clampf(sensitivity, 0.25, 3.0)
	invert_camera_y = invert_y
	touch_haptics_enabled = haptics

func get_movement_vector() -> Vector2:
	var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	if keyboard.length_squared() > 0.01:
		return keyboard.normalized()
	return virtual_move_vector.limit_length(1.0)

func set_virtual_move_vector(vec: Vector2) -> void:
	virtual_move_vector = vec.limit_length(1.0)

func trigger_haptic_tap(duration_ms: int = 18) -> void:
	if not touch_haptics_enabled:
		return
	if OS.has_feature("android") or OS.has_feature("mobile"):
		Input.vibrate_handheld(duration_ms)
