extends Node
## Offline modular .pck content pack scanner and loader foundation.
## Supports loading separately installed local expansion packs (city, vehicles, audio, missions)
## without exceeding single-APK size limits.

const PACK_SUBDIRS := ["city", "characters", "vehicles", "audio", "missions"]

var discovered_packs: Array[Dictionary] = []

func _ready() -> void:
	scan_local_packs()

func get_external_packs_root() -> String:
	# Android scoped app storage: /storage/emulated/0/Android/data/<pkg>/files/packs
	# Fallback to user://packs on desktop/sandbox testing.
	var data_dir := OS.get_user_data_dir()
	return data_dir.path_join("packs")

func ensure_pack_directories() -> void:
	var root := get_external_packs_root()
	var base_dir := DirAccess.open(OS.get_user_data_dir())
	if base_dir == null:
		return
	for sub in PACK_SUBDIRS:
		var rel := "packs/" + sub
		if not base_dir.dir_exists(rel):
			base_dir.make_dir_recursive(rel)
	ErrorHandler.log_info("ContentPackManager", "Local pack root verified: %s" % root)

func scan_local_packs() -> Array[Dictionary]:
	ensure_pack_directories()
	discovered_packs.clear()

	var root := get_external_packs_root()
	for sub in PACK_SUBDIRS:
		var folder := root.path_join(sub)
		var dir := DirAccess.open(folder)
		if dir == null:
			continue
		dir.list_dir_begin()
		var fname := dir.get_next()
		while fname != "":
			if not dir.current_is_dir() and fname.ends_with(".pck"):
				var full_path := folder.path_join(fname)
				discovered_packs.append({
					"category": sub,
					"filename": fname,
					"path": full_path,
					"mounted": false
				})
			fname = dir.get_next()
		dir.list_dir_end()

	EventBus.content_packs_scanned.emit(discovered_packs.size())
	ErrorHandler.log_info("ContentPackManager", "Scanned offline packs: %d found." % discovered_packs.size())
	return discovered_packs.duplicate()

func mount_pack(pack_path: String) -> bool:
	if not FileAccess.file_exists(pack_path):
		ErrorHandler.report_warning("ContentPackManager", "Pack missing: %s" % pack_path)
		return false
	var ok := ProjectSettings.load_resource_pack(pack_path, false)
	if not ok:
		ErrorHandler.report_error("ContentPackManager", "Failed to mount content pack: %s" % pack_path)
		return false
	for pack in discovered_packs:
		if pack["path"] == pack_path:
			pack["mounted"] = true
	ErrorHandler.log_info("ContentPackManager", "Mounted offline pack: %s" % pack_path)
	return true
