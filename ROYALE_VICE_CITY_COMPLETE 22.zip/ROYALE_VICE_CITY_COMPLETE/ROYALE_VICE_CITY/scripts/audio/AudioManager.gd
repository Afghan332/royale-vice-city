extends Node
## Manages Master, Music, and SFX audio buses and provides synthesized offline UI feedback.

const BUS_MASTER := "Master"
const BUS_MUSIC := "Music"
const BUS_SFX := "SFX"

var _ui_player: AudioStreamPlayer
var _playback: AudioStreamGeneratorPlayback
var _sample_rate: float = 22050.0
var _tone_phase: float = 0.0
var _tone_samples_remaining: int = 0
var _tone_freq: float = 640.0

func _ready() -> void:
	_ensure_audio_buses()
	_setup_ui_synthesizer()
	ErrorHandler.log_info("AudioManager", "Audio buses configured.")

func _ensure_audio_buses() -> void:
	for bus_name in [BUS_MUSIC, BUS_SFX]:
		if AudioServer.get_bus_index(bus_name) == -1:
			var idx := AudioServer.bus_count
			AudioServer.add_bus(idx)
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, BUS_MASTER)

func _setup_ui_synthesizer() -> void:
	_ui_player = AudioStreamPlayer.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = _sample_rate
	gen.buffer_length = 0.1
	_ui_player.stream = gen
	_ui_player.bus = BUS_SFX
	_ui_player.volume_db = -14.0
	add_child(_ui_player)
	_ui_player.play()
	_playback = _ui_player.get_stream_playback() as AudioStreamGeneratorPlayback

func _process(_delta: float) -> void:
	if _playback == null or _tone_samples_remaining <= 0:
		return
	var frames_available := _playback.get_frames_available()
	var frames_to_push := mini(frames_available, _tone_samples_remaining)
	for i in range(frames_to_push):
		var env := float(_tone_samples_remaining) / 1400.0
		var sample := sin(_tone_phase * TAU) * minf(env, 1.0) * 0.25
		_playback.push_frame(Vector2(sample, sample))
		_tone_phase = fmod(_tone_phase + (_tone_freq / _sample_rate), 1.0)
		_tone_samples_remaining -= 1

func apply_volumes(master_linear: float, music_linear: float, sfx_linear: float) -> void:
	_set_bus_linear(BUS_MASTER, master_linear)
	_set_bus_linear(BUS_MUSIC, music_linear)
	_set_bus_linear(BUS_SFX, sfx_linear)

func _set_bus_linear(bus_name: String, linear_value: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	var clamped := clampf(linear_value, 0.0, 1.0)
	AudioServer.set_bus_mute(idx, clamped <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(clamped, 0.0001)))

func play_ui_click() -> void:
	_trigger_tone(720.0, 900)

func play_ui_confirm() -> void:
	_trigger_tone(920.0, 1300)

func play_ui_back() -> void:
	_trigger_tone(480.0, 900)

func _trigger_tone(freq_hz: float, sample_count: int) -> void:
	if _playback == null:
		return
	_tone_freq = freq_hz
	_tone_phase = 0.0
	_tone_samples_remaining = sample_count
