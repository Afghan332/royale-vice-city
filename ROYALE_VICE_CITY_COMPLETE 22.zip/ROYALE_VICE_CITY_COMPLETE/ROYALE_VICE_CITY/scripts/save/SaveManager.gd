extends Node
## Offline local save/load & settings persistence manager.
## Stores settings in user://settings.cfg and campaign saves in user://saves/slot_<id>.json.

const SETTINGS_PATH := "user://settings.cfg"
const SAVES_DIR := "user://saves"
const SAVE_SCHEMA_VERSION := 1
const PRIMARY_SLOT := 1

const DEFAULT_SETTINGS := {
	"audio": {
		"master_volume": 0.85,
		"music_volume": 0.70,
		"sfx_volume": 0.90
	},
	"graphics": {
		"quality": "high",
		"max_fps": 60
	},
	"controls": {
		"camera_sensitivity": 1.0,
		"invert_y": false,
		"touch_haptics": true
	},
	"language": {
		"locale": "en"
	}
}

var current_settings: Dictionary = {}

func _ready() -> void:
	_ensure_save_directory()
	load_settings()

func _ensure_save_directory() -> void:
	var dir := DirAccess.open("user://")
	if dir != null and not dir.dir_exists("saves"):
		var err := dir.make_dir_recursive("saves")
		if err != OK:
			ErrorHandler.report_error("SaveManager", "Cannot create user://saves: %s" % error_string(err))

func get_default_settings() -> Dictionary:
	return DEFAULT_SETTINGS.duplicate(true)

func load_settings() -> Dictionary:
	current_settings = get_default_settings()
	var cfg := ConfigFile.new()
	if not FileAccess.file_exists(SETTINGS_PATH):
		save_settings(current_settings)
		return current_settings

	var err := cfg.load(SETTINGS_PATH)
	if err != OK:
		ErrorHandler.report_warning("SaveManager", "Corrupt settings.cfg, restoring defaults: %s" % error_string(err), true)
		save_settings(current_settings)
		return current_settings

	for section in DEFAULT_SETTINGS.keys():
		for key in DEFAULT_SETTINGS[section].keys():
			current_settings[section][key] = cfg.get_value(section, key, DEFAULT_SETTINGS[section][key])

	ErrorHandler.log_info("SaveManager", "Settings loaded from user://settings.cfg")
	return current_settings

func save_settings(settings_data: Dictionary) -> bool:
	var cfg := ConfigFile.new()
	for section in settings_data.keys():
		var section_dict: Dictionary = settings_data[section]
		for key in section_dict.keys():
			cfg.set_value(section, key, section_dict[key])

	var err := cfg.save(SETTINGS_PATH)
	if err != OK:
		ErrorHandler.report_error("SaveManager", "Failed to save settings: %s" % error_string(err))
		return false

	current_settings = settings_data.duplicate(true)
	ErrorHandler.log_info("SaveManager", "Settings persisted locally.")
	return true

func get_slot_path(slot_index: int) -> String:
	return "%s/slot_%d.json" % [SAVES_DIR, slot_index]

func has_save_slot(slot_index: int = PRIMARY_SLOT) -> bool:
	return FileAccess.file_exists(get_slot_path(slot_index))

func create_new_save_data(slot_index: int = PRIMARY_SLOT) -> Dictionary:
	var now := Time.get_datetime_string_from_system(false, true)
	return {
		"schema_version": SAVE_SCHEMA_VERSION,
		"game": "ROYALE_VICE_CITY",
		"slot": slot_index,
		"created_at": now,
		"updated_at": now,
		"phase": 1,
		"district": "Phase 1 Foundation Stage",
		"scene_path": "res://scenes/world/Phase1SandboxHub.tscn",
		"player": {
			"cash": 500,
			"position": [0.0, 1.0, 0.0]
		},
		"playtime_seconds": 0
	}

func save_game(slot_index: int, payload: Dictionary) -> bool:
	_ensure_save_directory()
	var data := payload.duplicate(true)
	data["schema_version"] = SAVE_SCHEMA_VERSION
	data["slot"] = slot_index
	data["updated_at"] = Time.get_datetime_string_from_system(false, true)

	var json_text := JSON.stringify(data, "\t")
	var temp_path := get_slot_path(slot_index) + ".tmp"
	var file := FileAccess.open(temp_path, FileAccess.WRITE)
	if file == null:
		ErrorHandler.report_error("SaveManager", "Failed to write temporary save file.")
		EventBus.save_completed.emit(slot_index, false)
		return false

	file.store_string(json_text)
	file.flush()
	file.close()

	var dir := DirAccess.open(SAVES_DIR)
	if dir == null:
		ErrorHandler.report_error("SaveManager", "Save directory inaccessible.")
		EventBus.save_completed.emit(slot_index, false)
		return false

	var target_name := "slot_%d.json" % slot_index
	var temp_name := target_name + ".tmp"
	if dir.file_exists(target_name):
		dir.remove(target_name)
	var rename_err := dir.rename(temp_name, target_name)
	if rename_err != OK:
		ErrorHandler.report_error("SaveManager", "Atomic save rename failed: %s" % error_string(rename_err))
		EventBus.save_completed.emit(slot_index, false)
		return false

	ErrorHandler.log_info("SaveManager", "Saved slot %d successfully." % slot_index)
	EventBus.save_completed.emit(slot_index, true)
	return true

func load_game(slot_index: int = PRIMARY_SLOT) -> Dictionary:
	var path := get_slot_path(slot_index)
	if not FileAccess.file_exists(path):
		return {}

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		ErrorHandler.report_error("SaveManager", "Could not open save file: %s" % path)
		return {}

	var text := file.get_as_text()
	file.close()

	var parsed: Variant = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		ErrorHandler.report_error("SaveManager", "Save slot %d is corrupted or unreadable." % slot_index)
		return {}

	if int(parsed.get("schema_version", 0)) > SAVE_SCHEMA_VERSION:
		ErrorHandler.report_warning("SaveManager", "Save slot %d uses newer schema version." % slot_index, true)

	EventBus.save_loaded.emit(slot_index, parsed)
	return parsed

func get_save_metadata(slot_index: int = PRIMARY_SLOT) -> Dictionary:
	var data := load_game(slot_index)
	if data.is_empty():
		return {}
	return {
		"slot": slot_index,
		"updated_at": str(data.get("updated_at", "")),
		"district": str(data.get("district", "")),
		"phase": int(data.get("phase", 1))
	}
