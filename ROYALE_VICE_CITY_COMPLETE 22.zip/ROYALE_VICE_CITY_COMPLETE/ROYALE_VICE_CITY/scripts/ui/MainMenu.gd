extends Control
## Main Menu screen controller: handles Continue, New Game (with overwrite confirmation), Settings, Quit, and error notices.

@onready var offline_label: Label = $ContentMargin/RootHBox/LeftColumn/OfflineLabel
@onready var title_label: Label = $ContentMargin/RootHBox/LeftColumn/TitleLabel
@onready var slogan_label: Label = $ContentMargin/RootHBox/LeftColumn/SloganLabel
@onready var save_summary_label: Label = $ContentMargin/RootHBox/LeftColumn/SaveSummaryLabel
@onready var continue_button: Button = $ContentMargin/RootHBox/LeftColumn/ButtonStack/ContinueButton
@onready var new_game_button: Button = $ContentMargin/RootHBox/LeftColumn/ButtonStack/NewGameButton
@onready var settings_button: Button = $ContentMargin/RootHBox/LeftColumn/ButtonStack/SettingsButton
@onready var quit_button: Button = $ContentMargin/RootHBox/LeftColumn/ButtonStack/QuitButton
@onready var phase_note_label: Label = $ContentMargin/RootHBox/RightColumn/PhaseNoteLabel
@onready var confirm_dialog: ConfirmationDialog = $ConfirmOverwriteDialog
@onready var error_dialog: AcceptDialog = $ErrorNoticeDialog

var _has_existing_save: bool = false

func _ready() -> void:
	continue_button.pressed.connect(_on_continue_pressed)
	new_game_button.pressed.connect(_on_new_game_pressed)
	settings_button.pressed.connect(_on_settings_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	confirm_dialog.confirmed.connect(_on_overwrite_confirmed)

	EventBus.language_changed.connect(_on_language_changed)
	ErrorHandler.error_reported.connect(_on_error_reported)

	_refresh_save_state()
	_apply_localized_text()

func _refresh_save_state() -> void:
	_has_existing_save = SaveManager.has_save_slot(SaveManager.PRIMARY_SLOT)
	continue_button.disabled = not _has_existing_save

func _apply_localized_text() -> void:
	offline_label.text = LocalizationManager.translate_key("MENU_OFFLINE_BADGE")
	title_label.text = LocalizationManager.translate_key("GAME_TITLE")
	slogan_label.text = LocalizationManager.translate_key("GAME_SLOGAN")
	continue_button.text = LocalizationManager.translate_key("MENU_CONTINUE")
	new_game_button.text = LocalizationManager.translate_key("MENU_NEW_GAME")
	settings_button.text = LocalizationManager.translate_key("MENU_SETTINGS")
	quit_button.text = LocalizationManager.translate_key("MENU_QUIT")

	if _has_existing_save:
		var meta := SaveManager.get_save_metadata(SaveManager.PRIMARY_SLOT)
		save_summary_label.text = LocalizationManager.translate_key("MENU_SAVE_INFO", {
			"slot": meta.get("slot", 1),
			"timestamp": meta.get("updated_at", "-")
		})
	else:
		save_summary_label.text = LocalizationManager.translate_key("MENU_NO_SAVE")

	confirm_dialog.dialog_text = LocalizationManager.translate_key("MENU_CONFIRM_OVERWRITE")
	confirm_dialog.ok_button_text = LocalizationManager.translate_key("CONFIRM_YES")
	confirm_dialog.cancel_button_text = LocalizationManager.translate_key("CONFIRM_CANCEL")
	error_dialog.title = LocalizationManager.translate_key("ERR_TITLE")
	error_dialog.ok_button_text = LocalizationManager.translate_key("ERR_DISMISS")

	var packs_found := ContentPackManager.discovered_packs.size()
	phase_note_label.text = "Godot 4.3 Mobile · ARM64 Offline\nLocal Content Packs Detected: %d" % packs_found

func _on_language_changed(_locale_code: String) -> void:
	_apply_localized_text()

func _on_continue_pressed() -> void:
	AudioManager.play_ui_confirm()
	InputManager.trigger_haptic_tap()
	GameManager.continue_game()

func _on_new_game_pressed() -> void:
	AudioManager.play_ui_click()
	InputManager.trigger_haptic_tap()
	if _has_existing_save:
		confirm_dialog.popup_centered()
	else:
		GameManager.start_new_game()

func _on_overwrite_confirmed() -> void:
	AudioManager.play_ui_confirm()
	InputManager.trigger_haptic_tap()
	GameManager.start_new_game()

func _on_settings_pressed() -> void:
	AudioManager.play_ui_click()
	InputManager.trigger_haptic_tap()
	GameManager.open_settings()

func _on_quit_pressed() -> void:
	AudioManager.play_ui_back()
	get_tree().quit()

func _on_error_reported(severity: String, source: String, message: String) -> void:
	error_dialog.dialog_text = "[%s] %s: %s" % [severity, source, message]
	error_dialog.popup_centered()
