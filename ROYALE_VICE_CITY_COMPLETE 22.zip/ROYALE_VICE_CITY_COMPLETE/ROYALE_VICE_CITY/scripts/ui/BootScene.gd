extends Control
## Boot scene controller: initializes offline subsystems sequentially and transitions to MainMenu.

@onready var progress_bar: ProgressBar = $CenterBox/ProgressBar
@onready var status_label: Label = $CenterBox/StatusLabel
@onready var title_label: Label = $CenterBox/TitleLabel
@onready var slogan_label: Label = $CenterBox/SloganLabel

func _ready() -> void:
	title_label.text = LocalizationManager.translate_key("GAME_TITLE")
	slogan_label.text = LocalizationManager.translate_key("GAME_SLOGAN")
	_run_boot_sequence()

func _run_boot_sequence() -> void:
	_set_step(0.20, "BOOT_INITIALIZING")
	await get_tree().create_timer(0.15).timeout

	_set_step(0.45, "BOOT_LOADING_SETTINGS")
	GameManager.initialize_subsystems()
	title_label.text = LocalizationManager.translate_key("GAME_TITLE")
	slogan_label.text = LocalizationManager.translate_key("GAME_SLOGAN")
	await get_tree().create_timer(0.15).timeout

	_set_step(0.75, "BOOT_CHECKING_SAVES")
	var _has_save := SaveManager.has_save_slot(SaveManager.PRIMARY_SLOT)
	await get_tree().create_timer(0.15).timeout

	_set_step(0.95, "BOOT_CHECKING_PACKS")
	ContentPackManager.scan_local_packs()
	await get_tree().create_timer(0.12).timeout

	_set_step(1.0, "BOOT_READY")
	await get_tree().create_timer(0.20).timeout
	GameManager.open_main_menu()

func _set_step(progress: float, key: String) -> void:
	progress_bar.value = progress * 100.0
	status_label.text = LocalizationManager.translate_key(key)
