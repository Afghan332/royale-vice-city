extends CanvasLayer
## Persistent loading overlay displayed by SceneManager during threaded scene switches.

@onready var loading_label: Label = $Backdrop/CenterContainer/Panel/LoadingLabel
@onready var progress_bar: ProgressBar = $Backdrop/CenterContainer/Panel/ProgressBar

func show_loading(initial_progress: float = 0.0) -> void:
	loading_label.text = LocalizationManager.translate_key("LOADING_LABEL")
	progress_bar.value = clampf(initial_progress, 0.0, 1.0) * 100.0
	visible = true

func update_progress(progress: float) -> void:
	progress_bar.value = clampf(progress, 0.0, 1.0) * 100.0

func hide_loading() -> void:
	visible = false
