extends Node3D
## Phase 1 Foundation 3D Stage: proves 3D Mobile Renderer, save persistence, and scene transitions work offline.

@onready var title_label: Label = $HUDLayer/TopBar/HeaderHBox/TitleLabel
@onready var subtitle_label: Label = $HUDLayer/TopBar/HeaderHBox/SubtitleLabel
@onready var save_button: Button = $HUDLayer/TopBar/HeaderHBox/SaveButton
@onready var menu_button: Button = $HUDLayer/TopBar/HeaderHBox/MenuButton
@onready var toast_label: Label = $HUDLayer/SaveToastLabel
@onready var camera_pivot: Node3D = $CameraPivot

func _ready() -> void:
	title_label.text = LocalizationManager.translate_key("HUB_TITLE")
	subtitle_label.text = LocalizationManager.translate_key("HUB_SUBTITLE")
	save_button.text = LocalizationManager.translate_key("HUB_SAVE_NOW")
	menu_button.text = LocalizationManager.translate_key("HUB_BACK_MENU")
	toast_label.visible = false

	save_button.pressed.connect(_on_save_pressed)
	menu_button.pressed.connect(_on_menu_pressed)

func _process(delta: float) -> void:
	if camera_pivot != null:
		camera_pivot.rotate_y(delta * 0.12)

func _on_save_pressed() -> void:
	AudioManager.play_ui_confirm()
	InputManager.trigger_haptic_tap()
	if GameManager.save_current_progress():
		toast_label.text = LocalizationManager.translate_key("HUB_SAVED_OK")
		toast_label.visible = true
		await get_tree().create_timer(2.5).timeout
		if is_instance_valid(toast_label):
			toast_label.visible = false

func _on_menu_pressed() -> void:
	AudioManager.play_ui_back()
	InputManager.trigger_haptic_tap()
	GameManager.open_main_menu()
