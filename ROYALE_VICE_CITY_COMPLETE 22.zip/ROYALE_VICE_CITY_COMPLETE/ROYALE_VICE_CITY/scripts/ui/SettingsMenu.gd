extends Control
## Settings screen controller: Audio, Graphics, Controls, and Language selection with local persistence.

@onready var title_label: Label = $MainMargin/RootVBox/HeaderRow/TitleLabel
@onready var back_button: Button = $MainMargin/RootVBox/HeaderRow/BackButton
@onready var category_tabs: TabContainer = $MainMargin/RootVBox/CategoryTabs

@onready var master_label: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/MasterRow/MasterLabel
@onready var master_slider: HSlider = $MainMargin/RootVBox/CategoryTabs/AudioTab/MasterRow/MasterSlider
@onready var master_value: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/MasterRow/MasterValue

@onready var music_label: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/MusicRow/MusicLabel
@onready var music_slider: HSlider = $MainMargin/RootVBox/CategoryTabs/AudioTab/MusicRow/MusicSlider
@onready var music_value: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/MusicRow/MusicValue

@onready var sfx_label: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/SfxRow/SfxLabel
@onready var sfx_slider: HSlider = $MainMargin/RootVBox/CategoryTabs/AudioTab/SfxRow/SfxSlider
@onready var sfx_value: Label = $MainMargin/RootVBox/CategoryTabs/AudioTab/SfxRow/SfxValue

@onready var quality_label: Label = $MainMargin/RootVBox/CategoryTabs/GraphicsTab/QualityRow/QualityLabel
@onready var quality_option: OptionButton = $MainMargin/RootVBox/CategoryTabs/GraphicsTab/QualityRow/QualityOption
@onready var fps_label: Label = $MainMargin/RootVBox/CategoryTabs/GraphicsTab/FpsRow/FpsLabel
@onready var fps_option: OptionButton = $MainMargin/RootVBox/CategoryTabs/GraphicsTab/FpsRow/FpsOption

@onready var sensitivity_label: Label = $MainMargin/RootVBox/CategoryTabs/ControlsTab/SensitivityRow/SensitivityLabel
@onready var sensitivity_slider: HSlider = $MainMargin/RootVBox/CategoryTabs/ControlsTab/SensitivityRow/SensitivitySlider
@onready var sensitivity_value: Label = $MainMargin/RootVBox/CategoryTabs/ControlsTab/SensitivityRow/SensitivityValue
@onready var invert_y_check: CheckButton = $MainMargin/RootVBox/CategoryTabs/ControlsTab/InvertYCheck
@onready var haptics_check: CheckButton = $MainMargin/RootVBox/CategoryTabs/ControlsTab/HapticsCheck

@onready var language_label: Label = $MainMargin/RootVBox/CategoryTabs/LanguageTab/LanguageRow/LanguageLabel
@onready var language_option: OptionButton = $MainMargin/RootVBox/CategoryTabs/LanguageTab/LanguageRow/LanguageOption

@onready var reset_button: Button = $MainMargin/RootVBox/FooterRow/ResetButton
@onready var apply_button: Button = $MainMargin/RootVBox/FooterRow/ApplyButton

var _working_settings: Dictionary = {}
var _quality_keys: Array[String] = ["low", "medium", "high"]
var _fps_values: Array[int] = [30, 60, 120]
var _locale_codes: Array[String] = []

func _ready() -> void:
	_working_settings = SaveManager.current_settings.duplicate(true)
	_connect_signals()
	_populate_options()
	_sync_ui_from_settings()
	_apply_localized_text()

func _connect_signals() -> void:
	back_button.pressed.connect(_on_back_pressed)
	reset_button.pressed.connect(_on_reset_pressed)
	apply_button.pressed.connect(_on_apply_pressed)

	master_slider.value_changed.connect(func(v: float) -> void:
		_working_settings["audio"]["master_volume"] = v
		master_value.text = "%d%%" % int(round(v * 100.0))
	)
	music_slider.value_changed.connect(func(v: float) -> void:
		_working_settings["audio"]["music_volume"] = v
		music_value.text = "%d%%" % int(round(v * 100.0))
	)
	sfx_slider.value_changed.connect(func(v: float) -> void:
		_working_settings["audio"]["sfx_volume"] = v
		sfx_value.text = "%d%%" % int(round(v * 100.0))
	)
	sensitivity_slider.value_changed.connect(func(v: float) -> void:
		_working_settings["controls"]["camera_sensitivity"] = v
		sensitivity_value.text = "%.2fx" % v
	)
	invert_y_check.toggled.connect(func(on: bool) -> void:
		_working_settings["controls"]["invert_y"] = on
	)
	haptics_check.toggled.connect(func(on: bool) -> void:
		_working_settings["controls"]["touch_haptics"] = on
	)
	quality_option.item_selected.connect(func(idx: int) -> void:
		if idx >= 0 and idx < _quality_keys.size():
			_working_settings["graphics"]["quality"] = _quality_keys[idx]
	)
	fps_option.item_selected.connect(func(idx: int) -> void:
		if idx >= 0 and idx < _fps_values.size():
			_working_settings["graphics"]["max_fps"] = _fps_values[idx]
	)
	language_option.item_selected.connect(func(idx: int) -> void:
		if idx >= 0 and idx < _locale_codes.size():
			var code := _locale_codes[idx]
			_working_settings["language"]["locale"] = code
			LocalizationManager.set_locale(code)
			_apply_localized_text()
	)

func _populate_options() -> void:
	quality_option.clear()
	quality_option.add_item(LocalizationManager.translate_key("QUALITY_LOW"))
	quality_option.add_item(LocalizationManager.translate_key("QUALITY_MEDIUM"))
	quality_option.add_item(LocalizationManager.translate_key("QUALITY_HIGH"))

	fps_option.clear()
	for fps in _fps_values:
		fps_option.add_item("%d FPS" % fps)

	language_option.clear()
	_locale_codes.clear()
	for lang in LocalizationManager.get_supported_languages():
		_locale_codes.append(str(lang.get("code", "en")))
		language_option.add_item(str(lang.get("name", "English")))

func _sync_ui_from_settings() -> void:
	var audio: Dictionary = _working_settings.get("audio", {})
	master_slider.value = float(audio.get("master_volume", 0.85))
	master_value.text = "%d%%" % int(round(master_slider.value * 100.0))
	music_slider.value = float(audio.get("music_volume", 0.70))
	music_value.text = "%d%%" % int(round(music_slider.value * 100.0))
	sfx_slider.value = float(audio.get("sfx_volume", 0.90))
	sfx_value.text = "%d%%" % int(round(sfx_slider.value * 100.0))

	var graphics: Dictionary = _working_settings.get("graphics", {})
	var q_idx := _quality_keys.find(str(graphics.get("quality", "high")))
	quality_option.select(maxi(q_idx, 0))
	var fps_idx := _fps_values.find(int(graphics.get("max_fps", 60)))
	fps_option.select(maxi(fps_idx, 0))

	var controls: Dictionary = _working_settings.get("controls", {})
	sensitivity_slider.value = float(controls.get("camera_sensitivity", 1.0))
	sensitivity_value.text = "%.2fx" % sensitivity_slider.value
	invert_y_check.button_pressed = bool(controls.get("invert_y", false))
	haptics_check.button_pressed = bool(controls.get("touch_haptics", true))

	var locale := str(_working_settings.get("language", {}).get("locale", "en"))
	var l_idx := _locale_codes.find(locale)
	language_option.select(maxi(l_idx, 0))

func _apply_localized_text() -> void:
	title_label.text = LocalizationManager.translate_key("SETTINGS_TITLE")
	back_button.text = LocalizationManager.translate_key("SETTINGS_BACK")
	reset_button.text = LocalizationManager.translate_key("SETTINGS_RESET")
	apply_button.text = LocalizationManager.translate_key("SETTINGS_APPLY")

	category_tabs.set_tab_title(0, LocalizationManager.translate_key("SETTINGS_TAB_AUDIO"))
	category_tabs.set_tab_title(1, LocalizationManager.translate_key("SETTINGS_TAB_GRAPHICS"))
	category_tabs.set_tab_title(2, LocalizationManager.translate_key("SETTINGS_TAB_CONTROLS"))
	category_tabs.set_tab_title(3, LocalizationManager.translate_key("SETTINGS_TAB_LANGUAGE"))

	master_label.text = LocalizationManager.translate_key("SETTINGS_MASTER_VOL")
	music_label.text = LocalizationManager.translate_key("SETTINGS_MUSIC_VOL")
	sfx_label.text = LocalizationManager.translate_key("SETTINGS_SFX_VOL")

	quality_label.text = LocalizationManager.translate_key("SETTINGS_QUALITY")
	fps_label.text = LocalizationManager.translate_key("SETTINGS_FPS_CAP")

	quality_option.set_item_text(0, LocalizationManager.translate_key("QUALITY_LOW"))
	quality_option.set_item_text(1, LocalizationManager.translate_key("QUALITY_MEDIUM"))
	quality_option.set_item_text(2, LocalizationManager.translate_key("QUALITY_HIGH"))

	sensitivity_label.text = LocalizationManager.translate_key("SETTINGS_SENSITIVITY")
	invert_y_check.text = LocalizationManager.translate_key("SETTINGS_INVERT_Y")
	haptics_check.text = LocalizationManager.translate_key("SETTINGS_VIBRATION")
	language_label.text = LocalizationManager.translate_key("SETTINGS_LANGUAGE_LABEL")

func _on_reset_pressed() -> void:
	AudioManager.play_ui_click()
	InputManager.trigger_haptic_tap()
	_working_settings = SaveManager.get_default_settings()
	_sync_ui_from_settings()
	LocalizationManager.set_locale(str(_working_settings["language"]["locale"]))
	_apply_localized_text()

func _on_apply_pressed() -> void:
	AudioManager.play_ui_confirm()
	InputManager.trigger_haptic_tap()
	GameManager.apply_all_settings(_working_settings, true)
	GameManager.open_main_menu()

func _on_back_pressed() -> void:
	AudioManager.play_ui_back()
	InputManager.trigger_haptic_tap()
	# Restore previously persisted locale if user backed out without applying
	var saved_locale := str(SaveManager.current_settings.get("language", {}).get("locale", "en"))
	LocalizationManager.set_locale(saved_locale)
	GameManager.open_main_menu()
