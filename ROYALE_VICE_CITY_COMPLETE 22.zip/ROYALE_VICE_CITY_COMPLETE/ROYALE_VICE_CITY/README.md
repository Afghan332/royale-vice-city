# ROYALE VICE CITY

**RULE THE CITY. OWN YOUR LEGACY.**

An original, fully offline, single-player 3D open-world action-adventure game built with **Godot Engine 4.3-stable** (GDScript, Mobile Renderer) targeting **Android ARM64** (reference test device: Samsung Galaxy S24 Ultra).

## Engine & Export Baseline
- **Godot Version:** `4.3-stable`
- **Renderer:** Mobile (`rendering/renderer/rendering_method="mobile"`)
- **Orientation:** Landscape (`1280x720` base stretch `canvas_items` / `expand`)
- **Target ABI:** `arm64-v8a` (64-bit Android ARM64)
- **Offline Architecture:** Zero internet permissions (`permissions/internet=false`), local `user://` saves and settings, modular local `.pck` content pack loader foundation.

## Phase 1 Deliverable Summary
- Boot initialization pipeline (`BootScene.tscn` / `BootScene.gd`)
- Persistent threaded scene loader (`SceneManager.gd` + `LoadingOverlay.tscn`)
- Functional Main Menu (`MainMenu.tscn` / `MainMenu.gd`) with `Continue`, `New Game` (overwrite confirmation), `Settings`, `Exit Game`
- Tabbed Settings screen (`SettingsMenu.tscn` / `SettingsMenu.gd`) for Audio, Graphics Presets (Low / Medium / High), Controls (Sensitivity, Invert Y, Touch Haptics), and Language (`en`, `es`, `fr`, `ar`, `fa`)
- Atomic local save/load system (`SaveManager.gd`) writing `user://saves/slot_1.json` and `user://settings.cfg`
- Audio bus and synthesized UI feedback (`AudioManager.gd`)
- Centralized runtime error logging (`ErrorHandler.gd`)
- Modular `.pck` pack registry foundation (`ContentPackManager.gd`)
- Playable 3D verification stage (`Phase1SandboxHub.tscn`) entered via `New Game` or `Continue`
- Automated headless test suite (`tests/scripts/test_phase1_foundation.gd`) and GitHub Actions ARM64 APK build workflow (`.github/workflows/android_build.yml`)

## iPhone-Only Cloud Workflow
1. Download `ROYALE_VICE_CITY_Phase1.zip` in iPhone Safari and extract in the iOS **Files** app.
2. Push or upload the extracted files to a GitHub repository.
3. Open the **Actions** tab on GitHub in iPhone Safari and run **Build Android ARM64 APK (Phase 1)**.
4. Download the generated APK artifact directly in Safari once the workflow succeeds and transfer to an Android ARM64 device for testing.
