# Licenses & Originality Statement

## Project Code & Assets
All GDScript source files, Godot scenes (`.tscn`), configuration files, localization strings, and vector branding SVGs (`app_icon.svg`, `splash_screen.svg`) in **ROYALE VICE CITY** are original creations authored for this project.

No third-party copyrighted characters, maps, logos, audio tracks, vehicles, or textures from external games are included.

## Engine & Tools
- **Godot Engine 4.3-stable** — MIT License (https://godotengine.org/license/)
- **Godot Export Templates 4.3-stable** — MIT License
