# Changelog

## [0.1.0-phase1] - Phase 1: Project Foundation
### Added
- Godot 4.3-stable project configuration (`project.godot`) with Mobile renderer, ETC2/ASTC texture compression, landscape orientation, and mobile touch emulation.
- Android ARM64 export preset (`export_presets.cfg`) with `arm64-v8a` enabled and `internet` permission disabled.
- Original vector branding assets (`assets/branding/app_icon.svg`, `assets/branding/splash_screen.svg`).
- 9 core autoload singletons: `ErrorHandler`, `EventBus`, `LocalizationManager`, `SaveManager`, `AudioManager`, `InputManager`, `ContentPackManager`, `SceneManager`, and `GameManager`.
- Runtime offline multi-language dictionary (`data/localization/translations.json`) supporting English, Spanish, French, Arabic, and Persian.
- Graphics quality preset profiles (`data/config/graphics_presets.json`) for Low, Medium, and High (Galaxy S24 Ultra).
- Complete UI and 3D stage scenes: `BootScene.tscn`, `LoadingOverlay.tscn`, `MainMenu.tscn`, `SettingsMenu.tscn`, and `Phase1SandboxHub.tscn`.
- Headless Phase 1 verification test script (`tests/scripts/test_phase1_foundation.gd`).
- Automated GitHub Actions ARM64 APK build pipeline (`.github/workflows/android_build.yml`).
